'use strict';
const responses = require("../../common/API-Responses");
const Dynamo = require('../../common/Dynamo');
const tableName2 = process.env.myDynamoDBTable2;

// LOGIN USER

exports.handler = async (event) => {

};